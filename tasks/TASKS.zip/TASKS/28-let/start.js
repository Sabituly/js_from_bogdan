/** ЗАДАЧА 28 - Let
 *
 * Измените код так, чтобы ошибка исчезла
 */

const myFavoriteAnimal = 'Monkey'

console.log(myFavoriteAnimal)
// 'Monkey'

const myFavoriteAnimal = 'Cat'

console.log(myFavoriteAnimal)
// 'Cat'
