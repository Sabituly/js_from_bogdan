/** ЗАДАЧА 19 - Добавление элементов в массив
 *
 * 1. Создайте любой массив
 *
 * 2. Добавьте в конец массива несколько новых элементов
 *
 * 3. Выведите в консоль длину результирующего массива
 */

const myNumbers = [4, 15, 107, 80]

console.log(myNumbers)

myNumbers.push(10)

console.log(myNumbers)

myNumbers.push(5, 25)

console.log(myNumbers)
console.log(myNumbers.length)
