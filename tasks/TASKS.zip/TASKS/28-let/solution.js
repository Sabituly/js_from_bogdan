/** ЗАДАЧА 28 - Let
 *
 * Измените код так, чтобы ошибка исчезла
 */

let myFavoriteAnimal = 'Monkey'

console.log(myFavoriteAnimal)
// 'Monkey'

myFavoriteAnimal = 'Cat'

console.log(myFavoriteAnimal)
// 'Cat'
