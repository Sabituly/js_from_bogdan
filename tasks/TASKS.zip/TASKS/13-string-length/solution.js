/** ЗАДАЧА 13 - Длина строки
 *
 * 1. Создайте переменную и присвойте ей любую строку
 *
 * 2. Виведите в консоль длину этой строки
 */

const myFavoriteSport = 'Snowboarding'

const stringLength = myFavoriteSport.length

console.log(stringLength)
